package com.suncorptest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@EnableSwagger2
@SpringBootApplication(scanBasePackages= {"com.suncorptest"})
public class SuncorpTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SuncorpTestApplication.class, args);
	}

}
