package com.suncorptest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages= {"com.suncorptest"})
public class SuncorpTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SuncorpTestApplication.class, args);
	}

}
