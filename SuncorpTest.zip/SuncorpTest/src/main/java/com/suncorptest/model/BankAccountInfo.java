package com.suncorptest.model;

import java.util.Date;

public class BankAccountInfo {

	private Long accountNumber;
	private String firstName;
	private String lastName;
	private Date dateOfBirth;
	private Date accountCreationDate;
	private Date accountUpdationDate;
	private String accountType;
	private double balanceAmount;
	private boolean active;

	public BankAccountInfo() {}

	public BankAccountInfo(Long accountNumber, String firstName, String lastName, Date dateOfBirth,
			Date accountCreationDate, Date accountUpdationDate, String accountType, double balanceAmount) {
		super();
		this.accountNumber = accountNumber;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.accountCreationDate = accountCreationDate;
		this.accountUpdationDate = accountUpdationDate;
		this.accountType = accountType;
		this.balanceAmount = balanceAmount;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Date getAccountCreationDate() {
		return accountCreationDate;
	}

	public void setAccountCreationDate(Date accountCreationDate) {
		this.accountCreationDate = accountCreationDate;
	}

	public Date getAccountUpdationDate() {
		return accountUpdationDate;
	}

	public void setAccountUpdationDate(Date accountUpdationDate) {
		this.accountUpdationDate = accountUpdationDate;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getBalanceAmount() {
		return balanceAmount;
	}

	public void setBalanceAmount(double balanceAmount) {
		this.balanceAmount = balanceAmount;
	}
	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "BankAccountInfo [accountNumber=" + accountNumber + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", dateOfBirth=" + dateOfBirth + ", accountCreationDate=" + accountCreationDate
				+ ", accountUpdationDate=" + accountUpdationDate + ", accountType=" + accountType + ", balanceAmount="
				+ balanceAmount + ", active=" + active + "]";
	}

}
