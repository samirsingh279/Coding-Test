package com.suncorptest.model;

public class Funds {
	private Long accountNumber;
	private Double amount;
	
	public Funds() {}
	
	public Funds(Long accountNumber, Double amount) {
		super();
		this.accountNumber = accountNumber;
		this.amount = amount;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Funds [accountNumber=" + accountNumber + ", amount=" + amount + "]";
	}
	
}
