package com.suncorptest.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.suncorptest.exception.AccountTransactionException;
import com.suncorptest.model.BankAccountInfo;
import com.suncorptest.model.Funds;
import com.suncorptest.model.TransferFunds;
import com.suncorptest.service.AccountService;

@RestController
@RequestMapping("/api")
public class AccountController {
	private static final Logger logger = LoggerFactory.getLogger(AccountController.class);
	
	@Autowired
	AccountService accountService;
	
	@GetMapping("/bankaccounts")
	public List<BankAccountInfo> listBankAccounts() {
		List<BankAccountInfo> bankAccountInfoList = accountService.listBankAccounts();
		logger.debug("bankAccountInfoList: "+bankAccountInfoList);
		return bankAccountInfoList;
	}
	
	@GetMapping("/bankaccounts/{accountNumber}")
	public BankAccountInfo findBankAccount(@PathVariable Long accountNumber) {
		BankAccountInfo bankAccountInfo = accountService.findBankAccount(accountNumber);
		logger.debug("accountNumber: "+accountNumber);
		return bankAccountInfo;
	}

	@PostMapping("/bankaccounts/openbankaccount")
	public BankAccountInfo openBankAccount(@RequestBody BankAccountInfo bankAccountInfo) {
		BankAccountInfo bankAccountInfoData = accountService.openBankAccount(bankAccountInfo);
		logger.debug("bankAccountInfo: "+ bankAccountInfo.toString());
		return bankAccountInfoData;
	}
	
	@PutMapping("/bankaccounts/editbankaccounttype")
	public void editBankAccountType(@RequestBody BankAccountInfo bankAccountInfo) throws AccountTransactionException {
		logger.debug("bankAccountInfo: "+ bankAccountInfo.toString());
		accountService.editBankAccountType(bankAccountInfo);
	}
	
	@PutMapping("/bankaccounts/depositfunds")
	public void depositFunds(@RequestBody Funds funds) throws AccountTransactionException {
		logger.debug("funds: "+funds.toString());
		accountService.depositFunds(funds.getAccountNumber(), funds.getAmount());
	}
	
	@PutMapping("/bankaccounts/withdrawfunds")
	public void withdrawFunds(@RequestBody Funds funds) throws AccountTransactionException {
		logger.debug("funds: "+funds.toString());
		accountService.withdrawFunds(funds.getAccountNumber(), funds.getAmount());
	}
	
	@PutMapping("/bankaccounts/transferfunds")
	public void transferFunds(@RequestBody TransferFunds transferFunds) throws AccountTransactionException {
		logger.debug("transferFunds: "+transferFunds.toString());
		accountService.transferFunds(transferFunds.getFromAccountNumber(), transferFunds.getToAccountNumber(), transferFunds.getAmount());
	}
	
}
