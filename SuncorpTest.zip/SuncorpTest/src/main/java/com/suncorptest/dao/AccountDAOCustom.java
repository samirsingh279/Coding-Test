package com.suncorptest.dao;

import java.util.List;

import com.suncorptest.entity.BankAccount;
import com.suncorptest.exception.AccountException;

public interface AccountDAOCustom {
	
	List<BankAccount> findActiveBankAccounts() throws AccountException;
}
