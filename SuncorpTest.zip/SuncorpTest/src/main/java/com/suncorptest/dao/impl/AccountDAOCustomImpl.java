package com.suncorptest.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.suncorptest.dao.AccountDAOCustom;
import com.suncorptest.entity.BankAccount;
import com.suncorptest.exception.AccountException;

@Repository("accountDAOCustom")
@Transactional
public class AccountDAOCustomImpl implements AccountDAOCustom{

	@PersistenceContext
    EntityManager entityManager;
	
	@Override
	public List<BankAccount> findActiveBankAccounts() throws AccountException {
		Query query = entityManager.createNativeQuery("SELECT account.* FROM BANK_ACCOUNT as account " +
                "WHERE account.ACTIVE = true", BankAccount.class);
        return query.getResultList();
	}

}
