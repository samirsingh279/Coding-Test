package com.suncorptest.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.suncorptest.entity.BankAccount;

@Repository
public interface AccountDAO extends JpaRepository<BankAccount, Long>{


}
