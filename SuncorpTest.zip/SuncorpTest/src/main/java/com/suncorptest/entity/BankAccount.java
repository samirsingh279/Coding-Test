package com.suncorptest.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BANK_ACCOUNT" )
public class BankAccount implements Serializable{
 
	private static final long serialVersionUID = -1587364882400157824L;
	
	public enum AccountType { 
		Deposit("Deposit"),
		Savings("Savings");

		private final String value;
		
		AccountType(final String value) {
			this.value = value;
		}

		@Override
		public String toString() {
			return value;
		}
	}  

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ACCOUNT_NUMBER", nullable = false)
    private Long accountNumber;
 
    @Column(name = "FIRST_NAME", length = 30, nullable = false)
    private String firstName;
    
    @Column(name = "LAST_NAME", length = 30, nullable = false)
    private String lastName;
    
    @Column(name = "DATE_OF_BIRTH", nullable = false)
	private Date dateOfBirth;
    
    @Column(name = "ACCOUNT_CREATION_DATE", nullable = false)
	private Date accountCreationDate;
    
    @Column(name = "ACCOUNT_UPDATION_DATE", nullable = false)
	private Date accountUpdationDate;
    
    @Column(name = "ACCOUNT_TYPE", length = 10, nullable = false)
    private String accountType;
    
    @Column(name = "BALANCE_AMOUNT", nullable = false)
    private double balanceAmount;

    public BankAccount() {}
    
	public BankAccount(String firstName, String lastName, Date dateOfBirth, Date accountCreationDate,
			Date accountUpdationDate, String accountType, double balanceAmount) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.accountCreationDate = accountCreationDate;
		this.accountUpdationDate = accountUpdationDate;
		this.accountType = accountType;
		this.balanceAmount = balanceAmount;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Date getAccountCreationDate() {
		return accountCreationDate;
	}

	public void setAccountCreationDate(Date accountCreationDate) {
		this.accountCreationDate = accountCreationDate;
	}

	
	public Date getAccountUpdationDate() {
		return accountUpdationDate;
	}

	public void setAccountUpdationDate(Date accountUpdationDate) {
		this.accountUpdationDate = accountUpdationDate;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getBalanceAmount() {
		return balanceAmount;
	}

	public void setBalanceAmount(double balanceAmount) {
		this.balanceAmount = balanceAmount;
	}
	

	@Override
	public String toString() {
		return "BankAccount [accountNumber=" + accountNumber + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", dateOfBirth=" + dateOfBirth + ", accountCreationDate=" + accountCreationDate
				+ ", accountUpdationDate=" + accountUpdationDate + ", accountType=" + accountType + ", balanceAmount="
				+ balanceAmount + "]";
	}
	
	
}
