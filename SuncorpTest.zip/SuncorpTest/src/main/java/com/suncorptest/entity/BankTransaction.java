package com.suncorptest.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "BANK_TRANSACTION")
public class BankTransaction implements Serializable{
	private static final long serialVersionUID = 5442352706341721852L;
	
	public enum TransactionType { 
		Debit("Debit"),
		Credit("Credit");

		private final String value;
		
		TransactionType(final String value) {
			this.value = value;
		}

		@Override
		public String toString() {
			return value;
		}
	}  
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "TRANSACTION_ID", nullable = false)
    private Long transactionId;
 
    @Column(name = "TRANSACTION_DATE", nullable = false)
	private Date transactionDate;
    
    @Column(name = "TRANSACTION_TYPE", length = 10, nullable = false)
    private String transactionType;
    
    @Column(name = "TRANSACTION_AMOUNT", nullable = false)
    private double amount;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ACCOUNT_NUMBER")
    private BankAccount bankAccount;
    
    @Column(name = "REMARKS", length = 50, nullable = false)
    private String remarks;

    public BankTransaction() {}
    
	public BankTransaction(Date transactionDate, double amount, BankAccount bankAccount) {
		super();
		this.transactionDate = transactionDate;
		this.amount = amount;
		this.bankAccount = bankAccount;
	}

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public BankAccount getBankAccount() {
		return bankAccount;
	}

	public void setBankAccount(BankAccount bankAccount) {
		this.bankAccount = bankAccount;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Override
	public String toString() {
		return "BankTransaction [transactionId=" + transactionId + ", transactionDate=" + transactionDate
				+ ", transactionType=" + transactionType + ", amount=" + amount + ", bankAccount="
				+ bankAccount.toString() + ", remarks=" + remarks + "]";
	}
    
    
}
