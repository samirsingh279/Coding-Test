package com.suncorptest.exception;

public class AccountException extends Exception{

	private static final long serialVersionUID = 6531399398602371055L;

	public AccountException(String message) {
        super(message);
    }

}
