package com.suncorptest.exception;

public class AccountTransactionException extends Exception{
	
	private static final long serialVersionUID = -1865352868984508720L;

	public AccountTransactionException(String message) {
        super(message);
    }
}
