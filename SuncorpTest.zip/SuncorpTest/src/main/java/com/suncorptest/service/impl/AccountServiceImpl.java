package com.suncorptest.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.suncorptest.dao.AccountDAO;
import com.suncorptest.entity.BankAccount;
import com.suncorptest.exception.AccountTransactionException;
import com.suncorptest.model.BankAccountInfo;
import com.suncorptest.service.AccountService;

@Service
@Transactional(propagation = Propagation.REQUIRED)
public class AccountServiceImpl implements AccountService{
	private static final Logger logger = LoggerFactory.getLogger(AccountServiceImpl.class);	
	
	@Autowired
	AccountDAO accountDAO;
	
	@Override
	public BankAccountInfo openBankAccount(BankAccountInfo bankAccountInfo) {
		BankAccount bankAccount = new BankAccount();
		BeanUtils.copyProperties(bankAccountInfo, bankAccount); // Copying model object data to entity object to save to database.
		bankAccount.setAccountCreationDate(new Date());
		bankAccount.setAccountUpdationDate(new Date());
		String accountType = BankAccount.AccountType.valueOf(bankAccountInfo.getAccountType()).toString();
		bankAccount.setAccountType(accountType);
		bankAccount = accountDAO.save(bankAccount);
		logger.debug("bankAccount: "+bankAccount.toString());
		BeanUtils.copyProperties(bankAccount, bankAccountInfo); // Exchanging saved data to model object to return to client.
		
		return bankAccountInfo;
	}

	@Override
	public List<BankAccountInfo> listBankAccounts() {
		List<BankAccountInfo> bankAccountInfoList = new ArrayList<>();
		List<BankAccount> bankaccountList = accountDAO.findAll();
		for(BankAccount bankAccount : bankaccountList) {
			logger.debug("bankAccount in ireteation: "+bankAccount.toString());
			BankAccountInfo bankAccountInfo = new BankAccountInfo();
			BeanUtils.copyProperties(bankAccount, bankAccountInfo); // Exchanging fetched data to model object to return to client.
			bankAccountInfoList.add(bankAccountInfo);
		}
		return bankAccountInfoList;
	}
	
	@Override
	public BankAccountInfo findBankAccount(Long accountNumber) {
		Optional<BankAccount> bankAccountOptional = accountDAO.findById(accountNumber);
		BankAccount bankAccount = bankAccountOptional.get();
		BankAccountInfo bankAccountInfo = new BankAccountInfo();
		BeanUtils.copyProperties(bankAccount, bankAccountInfo); // Exchanging fetched data to model object to return to client.
		logger.debug("bankAccountInfo: "+bankAccountInfo.toString());
		return bankAccountInfo;
	}

	@Override
	public void depositFunds(Long accountNumber, double amount) throws AccountTransactionException {
		Optional<BankAccount> bankAccountOptional = accountDAO.findById(accountNumber);
		BankAccount bankAccount = bankAccountOptional.get();
		if (bankAccount == null) {
			throw new AccountTransactionException("Bank Account not found " + accountNumber);
		}
		logger.debug("bankAccount: "+bankAccount.toString());
		double newBalance = bankAccount.getBalanceAmount() + amount;
		logger.debug("accountNumber: "+accountNumber+" newBalance: "+newBalance);
		if (bankAccount.getBalanceAmount() + amount < 0) {
			throw new AccountTransactionException(
					"The funds in the account '" + accountNumber + "' is not enough (" + bankAccount.getBalanceAmount() + ")");
		}
		bankAccount.setBalanceAmount(newBalance);
		bankAccount.setAccountUpdationDate(new Date());
		accountDAO.save(bankAccount);

	}

	@Override
	public void withdrawFunds(Long accountNumber, double amount) throws AccountTransactionException {
		Optional<BankAccount> bankAccountOptional = accountDAO.findById(accountNumber);
		BankAccount bankAccount = bankAccountOptional.get();
		if (bankAccount == null) {
			throw new AccountTransactionException("Bank Account not found " + accountNumber);
		}
		logger.debug("bankAccount: "+bankAccount.toString());
		double newBalance = bankAccount.getBalanceAmount() - amount;
		logger.debug("newBalance: "+newBalance);
		if (bankAccount.getBalanceAmount() - amount < 0) {
			throw new AccountTransactionException(
					"The funds in the account '" + accountNumber + "' is not enough (" + bankAccount.getBalanceAmount() + ")");
		}
		bankAccount.setBalanceAmount(newBalance);
		bankAccount.setAccountUpdationDate(new Date());
		accountDAO.save(bankAccount);
		
	}

	@Override
	public void transferFunds(Long fromAccountId, Long toAccountId, double amount) throws AccountTransactionException {
		logger.debug("fromAccountId: "+fromAccountId+ " toAccountId: "+toAccountId +" amount"+amount);
		depositFunds(toAccountId, amount);
		depositFunds(fromAccountId, -amount);
	}

	@Override
	public void editBankAccountType(BankAccountInfo bankAccountInfo) throws AccountTransactionException {
		Optional<BankAccount> bankAccountOptional = accountDAO.findById(bankAccountInfo.getAccountNumber());
		BankAccount bankAccount = bankAccountOptional.get();
		if (bankAccount == null) {
			throw new AccountTransactionException("Bank Account not found " + bankAccountInfo.getAccountNumber());
		}
		logger.debug("bankAccount: "+bankAccount.toString());
		String accountType = BankAccount.AccountType.valueOf(bankAccountInfo.getAccountType()).toString();
		bankAccount.setAccountType(accountType);
		bankAccount.setAccountUpdationDate(new Date());
		accountDAO.save(bankAccount);
		
	}

}
