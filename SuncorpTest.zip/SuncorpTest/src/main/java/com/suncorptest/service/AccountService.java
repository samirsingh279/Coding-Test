package com.suncorptest.service;

import java.util.List;

import com.suncorptest.exception.AccountTransactionException;
import com.suncorptest.model.BankAccountInfo;

public interface AccountService {
	BankAccountInfo openBankAccount(BankAccountInfo bankAccountInfo);

	List<BankAccountInfo> listBankAccounts();
	
	BankAccountInfo findBankAccount(Long accountNumber);

	void depositFunds(Long accountNumber, double amount) throws AccountTransactionException;

	void withdrawFunds(Long accountNumber, double amount) throws AccountTransactionException;

	void transferFunds(Long fromAccountId, Long toAccountId, double amount) throws AccountTransactionException;

	void editBankAccountType(BankAccountInfo bankAccountInfo) throws AccountTransactionException;
}
