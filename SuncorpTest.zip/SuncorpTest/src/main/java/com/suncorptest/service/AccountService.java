package com.suncorptest.service;

import java.util.List;

import com.suncorptest.exception.AccountException;
import com.suncorptest.exception.AccountTransactionException;
import com.suncorptest.model.BankAccountInfo;
import com.suncorptest.model.Transaction;

public interface AccountService {
	BankAccountInfo openBankAccount(BankAccountInfo bankAccountInfo) throws AccountException;

	List<BankAccountInfo> listBankAccounts() throws AccountException;
	
	BankAccountInfo findBankAccount(Long accountNumber) throws AccountException;

	void depositFunds(Long accountNumber, double amount) throws AccountTransactionException;

	void withdrawFunds(Long accountNumber, double amount) throws AccountTransactionException;

	void transferFunds(Long fromAccountId, Long toAccountId, double amount) throws AccountTransactionException;

	void editBankAccountType(BankAccountInfo bankAccountInfo) throws  AccountException;

	List<Transaction> viewTransactions(Long accountNumber)  throws AccountException, AccountTransactionException;
}
