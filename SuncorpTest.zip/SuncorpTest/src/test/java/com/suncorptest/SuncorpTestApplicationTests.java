package com.suncorptest;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SuncorpTestApplicationTests {

	@Test
	public void contextLoads() {
	}

}
