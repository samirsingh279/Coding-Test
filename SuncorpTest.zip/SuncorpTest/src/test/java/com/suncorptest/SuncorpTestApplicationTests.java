package com.suncorptest;

//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuncorpTestApplicationTests {

	//@Test
	void contextLoads() {
	}

}
