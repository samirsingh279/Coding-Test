package com.suncorptest.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.BeanUtils;

import com.suncorptest.dao.AccountDAO;
import com.suncorptest.dao.AccountDAOCustom;
import com.suncorptest.entity.BankAccount;
import com.suncorptest.entity.BankTransaction;
import com.suncorptest.exception.AccountException;
import com.suncorptest.exception.AccountTransactionException;
import com.suncorptest.model.BankAccountInfo;
import com.suncorptest.model.Transaction;

@RunWith(PowerMockRunner.class)
@PrepareForTest({AccountServiceImpl.class})
public class AccountServiceImplTest {
	
	@Mock
    private AccountDAO accountDAO;
	
	@Mock
	AccountDAOCustom accountDAOCustom;
 
    @InjectMocks
    private AccountServiceImpl accountService;
 
    @Before
    public void setUp() throws Exception {
       MockitoAnnotations.initMocks(this);
    }
    
    /**
     * Test case to open new account
     */
    @Test
    public void openBankAccountTest() {
    	BankAccountInfo bankAccountInfo = new BankAccountInfo(1L, "Samir", "Singh", new Date(), 
    			new Date(), new Date(), BankAccount.AccountType.Savings.toString(), 50.00);
    	
    	BankAccount bankAccount = new BankAccount();
    	BeanUtils.copyProperties(bankAccountInfo,bankAccount); // Exchanging saved data to model object to return to client.
    	
    	PowerMockito.when(accountDAO.save(any(BankAccount.class))).thenReturn(bankAccount);
    	
    	bankAccountInfo = accountService.openBankAccount(bankAccountInfo);
    	assertNotNull(bankAccountInfo);
    	assertEquals(bankAccount.getAccountNumber(), bankAccountInfo.getAccountNumber());
    }
    
    /**
     * Test case to deposit funds
     * @throws AccountTransactionException
     */
    @Test()
    public void depositFundsTest() throws AccountTransactionException {
    	Optional<BankAccount> bankAccountOptional = getBankAccountOptional(1L);
    	PowerMockito.when(accountDAO.findById(1L)).thenReturn(bankAccountOptional);
    	accountService.depositFunds(1L, 10.00);
    }
    
    /**
     * Test case to deposit funds with minus balance amount
     * @throws AccountTransactionException
     */
    @Test(expected=AccountTransactionException.class)
    public void depositFundsWithMinusAmountTest() throws AccountTransactionException {
    	Optional<BankAccount> bankAccountOptional = getBankAccountOptional(1L);
    	PowerMockito.when(accountDAO.findById(1L)).thenReturn(bankAccountOptional);
    	accountService.depositFunds(1L, -15.00);
    }
    /**
     * Test case to withdraw funds on available sufficient balance amount.
     * @throws AccountTransactionException
     */
    @Test()
    public void withdrawFundsTest() throws AccountTransactionException {
    	Optional<BankAccount> bankAccountOptional = getBankAccountOptional(1L);
    	PowerMockito.when(accountDAO.findById(1L)).thenReturn(bankAccountOptional);
    	accountService.depositFunds(1L, 10.00);
    }
    
    /**
     * Test case to withdraw funds on available insufficient balance amount.
     * @throws AccountTransactionException
     */
    @Test(expected=AccountTransactionException.class)
    public void withdrawFundsIfInsufficientBalanceTest() throws AccountTransactionException {
    	Optional<BankAccount> bankAccountOptional = getBankAccountOptional(1L);
    	PowerMockito.when(accountDAO.findById(1L)).thenReturn(bankAccountOptional);
    	accountService.depositFunds(1L, -15.00);
    }
    
    /**
     * Test case to get account details
     */
    @Test
    public void findBankAccountTest() {
    	Optional<BankAccount> bankAccountOptional = getBankAccountOptional(1L);
    	
    	PowerMockito.when(accountDAO.findById(1L)).thenReturn(bankAccountOptional);
    	
    	BankAccountInfo bankAccountInfo = accountService.findBankAccount(1L);
    	assertNotNull(bankAccountInfo);
    	assertEquals("Samir", bankAccountInfo.getFirstName());
    }
    
    /**
     * Test case to get all accounts details
     * @throws AccountException 
     */
    @Test
    public void listBankAccountsTest() throws AccountException {
    	List<BankAccount> bankaccountList = new ArrayList<>();
    	BankAccount account1 = new BankAccount("Samir", "Singh", new Date(), new Date(), new Date(), BankAccount.AccountType.Savings.toString(), 0);
    	account1.setAccountNumber(1L);
    	account1.setActive(true);
    	BankAccount account2 = new BankAccount("John", "Maq", new Date(), new Date(), new Date(), BankAccount.AccountType.Deposit.toString(), 0);
    	account2.setAccountNumber(2L);
    	account2.setActive(true);
    	bankaccountList.add(account1);
    	bankaccountList.add(account2);
    	
    	PowerMockito.when(accountDAOCustom.findActiveBankAccounts()).thenReturn(bankaccountList);
    	
    	List<BankAccountInfo> bankAccountInfoList = accountService.listBankAccounts();
    	assertNotNull(bankAccountInfoList);
    	assertTrue(bankAccountInfoList.size() > 0);
    	assertEquals("Maq", bankAccountInfoList.get(1).getLastName());
    }
    
    /**
     * Test case to transfer funds from one account to another account on available sufficient balance amount
     * @throws AccountTransactionException
     */
    @Test()
    public void transferFundsTest() throws AccountTransactionException {
    	Optional<BankAccount> bankAccountOptional1 = getBankAccountOptional(1L);
    	Optional<BankAccount> bankAccountOptional2 = getBankAccountOptional(2L);
    	PowerMockito.when(accountDAO.findById(1L)).thenReturn(bankAccountOptional1);
    	PowerMockito.when(accountDAO.findById(2L)).thenReturn(bankAccountOptional2);
    	accountService.transferFunds(1L, 2L, 5.00);
    	assertTrue(bankAccountOptional2.get().getBalanceAmount() == 15.00);
    }
    
    /**
     * Test case to transfer funds from one account to another account on available insufficient balance amount
     * @throws AccountTransactionException
     */
    @Test(expected=AccountTransactionException.class)
    public void transferFundsIfInsufficientBalanceTest() throws AccountTransactionException {
    	Optional<BankAccount> bankAccountOptional1 = getBankAccountOptional(1L);
    	Optional<BankAccount> bankAccountOptional2 = getBankAccountOptional(2L);
    	PowerMockito.when(accountDAO.findById(1L)).thenReturn(bankAccountOptional1);
    	PowerMockito.when(accountDAO.findById(2L)).thenReturn(bankAccountOptional2);
    	accountService.transferFunds(1L, 2L, 15.00);
    }
    
    /**
     * Test case to edit bank account type
     * @throws AccountException
     */
    @Test
    public void editBankAccountTypeTest() throws AccountException {
    	Optional<BankAccount> bankAccountOptional = getBankAccountOptional(1L);
    	BankAccountInfo bankAccountInfo = new BankAccountInfo();
    	BeanUtils.copyProperties(bankAccountOptional.get(), bankAccountInfo);
    	
    	PowerMockito.when(accountDAO.findById(1L)).thenReturn(bankAccountOptional);
    	bankAccountInfo.setAccountType(BankAccount.AccountType.Deposit.toString()); // earlier account type was Savings, Now changing it by Deposit type. 
    	accountService.editBankAccountType(bankAccountInfo);
    	assertEquals(BankAccount.AccountType.Deposit.toString(), bankAccountInfo.getAccountType());
    }
    
    /**
     * Test case to view transactions
     * @throws AccountTransactionException
     */
    @Test()
    public void viewTransactionsTest() throws AccountTransactionException {
    	Optional<BankAccount> bankAccountOptional = getBankAccountOptional(1L);
    	PowerMockito.when(accountDAO.findById(1L)).thenReturn(bankAccountOptional);
    	List<Transaction> transactions = accountService.viewTransactions(1L);
    	assertNotNull(transactions);
    	assertTrue(transactions.size() > 0);
    }
    
    private Optional<BankAccount> getBankAccountOptional(Long accountNumber){
    	BankAccount account = new BankAccount("Samir", "Singh", new Date(), new Date(), new Date(), BankAccount.AccountType.Savings.toString(), 10.00);
    	account.setAccountNumber(accountNumber);
    	account.setActive(true);
    	account.setBankTransactions(getBankTransactions());
    	
    	Optional<BankAccount> bankAccountOptional = Optional.of(account);
    	return bankAccountOptional;
    }
    
    private Set<BankTransaction> getBankTransactions(){
    	Set<BankTransaction> transactionSet = new HashSet<>();
    	BankTransaction transaction = new BankTransaction(new Date(),10.00,null);
    	transaction.setTransactionType(BankTransaction.TransactionType.Credit.toString());
    	transaction.setRemarks("Deposite");
    	transactionSet.add(transaction);
    	return transactionSet;
    }

}
